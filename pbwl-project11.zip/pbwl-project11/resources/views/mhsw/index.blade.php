@extends('layouts.app')

@section('content')

<h2>Data Mahasiswa</h2>

<a href="{{ url('mhsw/create') }}">Tambah Data</a>

<table class="table table-bordered">;
    <tr>
        <th>ID</th>
        <th>NIM</th>
        <th>NAMA</th>
        <th>ALAMAT</th>
        <th>EDIT</th>
        <th>DELETE</th>
    </tr>
    @foreach ($rows as $rows)
    <tr>
        <td>{{ $rows->mhsw_id }}</td>
        <td>{{ $rows->mhsw_nim}}</td>
        <td>{{ $rows->mhsw_nama}}</td>
        <td>{{ $rows->mhsw_alamat}}</td>
        <td><a href="{{ url('mhsw/edit/'.$rows->mhsw_id ) }}">Edit</a></td>
        <td><a href="{{ url('mhsw/delete/'.$rows->mhsw_id ) }}">Delete</a></td>
        <td></td>
    </tr>
@endforeach

</table>
@endsection