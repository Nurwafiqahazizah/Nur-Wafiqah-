@extends('layouts.app')

@section('content')

<h2>Edit Tambah Data Mahasiswa</h2>

<from action="{{ url('mhsw/' . $row->mhsw_id)}}" method="post">
    <input type="hidden" name="_method" value="PATCH">
    @csrf
    <div class="mb-3">
        <label for="">NIM</label>
        <input type="text" nama="mhsw_nim" id="" class="from-control" value="{{$row->mhsw_nim}}">
    </div>
    <div class="mb-3">
        <label for="">NAMA</label>
        <input type="text" nama="mhsw_nama" id="" class="from-control" value="{{$row->mhsw_nama}}">>
    </div>
    <div class="mb-3">
        <label for="">ALAMAT</label>
        <textarea name="mhsw_alamat" class="form-control" id="" cols="30" rows="10> value="{{$row->mhsw_alamat}}"></textarea>
    </div>
    <div class="mb-3">
        <input type="submit" value="UPDATE" class="btn btn-primary">
    </div>
</from>
@endsection