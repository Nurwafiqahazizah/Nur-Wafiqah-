

<?php $__env->startSection('content'); ?>

<h2>Edit Tambah Data Mahasiswa</h2>

<from action="<?php echo e(url('mhsw/' . $row->mhsw_id)); ?>" method="post">
    <input type="hidden" name="_method" value="PATCH">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="">NIM</label>
        <input type="text" nama="mhsw_nim" id="" class="from-control" value="<?php echo e($row->mhsw_nim); ?>">
    </div>
    <div class="mb-3">
        <label for="">NAMA</label>
        <input type="text" nama="mhsw_nama" id="" class="from-control" value="<?php echo e($row->mhsw_nama); ?>">>
    </div>
    <div class="mb-3">
        <label for="">ALAMAT</label>
        <textarea name="mhsw_alamat" class="form-control" id="" cols="30" rows="10> value="<?php echo e($row->mhsw_alamat); ?>"></textarea>
    </div>
    <div class="mb-3">
        <input type="submit" value="UPDATE" class="btn btn-primary">
    </div>
</from>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\si3\pbwl-project11\resources\views/mhsw/edit.blade.php ENDPATH**/ ?>