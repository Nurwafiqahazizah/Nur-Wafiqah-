

<?php $__env->startSection('content'); ?>

<h2>Data Mahasiswa</h2>

<a href="<?php echo e(url('mhsw/create')); ?>">Tambah Data</a>

<table class="table table-bordered">;
    <tr>
        <th>ID</th>
        <th>NIM</th>
        <th>NAMA</th>
        <th>ALAMAT</th>
        <th>EDIT</th>
        <th>DELETE</th>
    </tr>
    <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($rows->mhsw_id); ?></td>
        <td><?php echo e($rows->mhsw_nim); ?></td>
        <td><?php echo e($rows->mhsw_nama); ?></td>
        <td><?php echo e($rows->mhsw_alamat); ?></td>
        <td><a href="<?php echo e(url('mhsw/edit/'.$rows->mhsw_id )); ?>">Edit</a></td>
        <td><a href="<?php echo e(url('mhsw/delete/'.$rows->mhsw_id )); ?>">Delete</a></td>
        <td></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\si3\pbwl-project11\resources\views/mhsw/index.blade.php ENDPATH**/ ?>